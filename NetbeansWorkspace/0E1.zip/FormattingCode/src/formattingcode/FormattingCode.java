/*
 * To change this license header, choose License Headers in Project Properties.
 * TAuto Formatting
 */
package formattingcode;

/**
 *
 * @author StruthersA
 * @since 2-26-2018 I pledge that this program represents my own program code. I
 * received code from and shared my code with no one.
 */
public class FormattingCode {

    public static void main(String[] args) {
        System.out.println("Hello ");
    }

}
