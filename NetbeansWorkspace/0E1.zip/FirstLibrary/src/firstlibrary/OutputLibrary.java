/*
 * To change this license header, choose License Headers in Project Properties.
 * TAuto Formatting
 */
package firstlibrary;

/**
 *
 * @author StruthersA
 * @since 2-26-2018 I pledge that this program represents my own program code. I
 * received code from and shared my code with no one.
 */
public class OutputLibrary {

    public void out() {
        System.out.println("run called out. Now in out");
    }
}
